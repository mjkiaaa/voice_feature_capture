function [B]=normlizeA(A)
% This function is made by lbq
% Its main function is for normlize array A by row
% B:stands for output array of normlized one
% A:stands for input array

[m,n]=size(A);
% normlize each row to unit
for i=1:m
	B(i,:)=A(i,:)/norm(A(i,:));
end